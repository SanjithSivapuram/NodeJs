module.exports = {
  url: "mongodb://cosmos-db-identitymanagment:x33duCjaTTp5M8khxXdu4ZjKy7nZbCRZLATIXIbWwlUBC5QlXw131tvylaMFd4aIiP9Eyu3gaMVoqyEKGbK5VA==@cosmos-db-identitymanagment.mongo.cosmos.azure.com:10255/employee?ssl=true&retrywrites=false&maxIdleTimeMS=120000&appName=@cosmos-db-identitymanagment@"
};
